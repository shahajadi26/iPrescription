import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Upload, FileText, CheckCircle2, AlertCircle } from 'lucide-react';

interface CSVUploadProps {
  onUpload: (data: unknown[]) => Promise<void>;
  templateColumns: string[];
  moduleName: string;
}

export default function CSVUpload({ onUpload, templateColumns, moduleName }: CSVUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const parseCSV = (text: string): unknown[] => {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length < 2) {
      throw new Error('CSV file must have at least a header row and one data row');
    }

    const headers = lines[0].split(',').map(h => h.trim());
    
    const missingColumns = templateColumns.filter(col => !headers.includes(col));
    if (missingColumns.length > 0) {
      throw new Error(`Missing required columns: ${missingColumns.join(', ')}`);
    }

    const data: unknown[] = [];
    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const row: Record<string, string> = {};
      
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      
      data.push(row);
    }

    return data;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (!selectedFile.name.endsWith('.csv')) {
        setError('Please select a CSV file');
        return;
      }
      setFile(selectedFile);
      setError('');
      setSuccess(false);
    }
  };

  const handleUpload = async () => {
    if (!file) {
      setError('Please select a file first');
      return;
    }

    setUploading(true);
    setError('');
    setProgress(0);

    try {
      const text = await file.text();
      setProgress(30);

      const data = parseCSV(text);
      setProgress(60);

      await onUpload(data);
      setProgress(100);

      setSuccess(true);
      setFile(null);
      
      const fileInput = document.getElementById('csv-upload') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
      setTimeout(() => setProgress(0), 1000);
    }
  };

  const downloadTemplate = () => {
    const csvContent = templateColumns.join(',') + '\n';
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${moduleName}_template.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label htmlFor="csv-upload" className="text-base font-semibold">
          Bulk Upload CSV
        </Label>
        <Button variant="outline" size="sm" onClick={downloadTemplate}>
          <FileText className="w-4 h-4 mr-2" />
          Download Template
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="border-success bg-success/10">
          <CheckCircle2 className="w-4 h-4 text-success" />
          <AlertDescription className="text-success">
            CSV uploaded successfully!
          </AlertDescription>
        </Alert>
      )}

      <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
        <input
          id="csv-upload"
          type="file"
          accept=".csv"
          onChange={handleFileChange}
          className="hidden"
        />
        <Label htmlFor="csv-upload" className="cursor-pointer">
          <div className="flex flex-col items-center gap-2">
            <Upload className="w-12 h-12 text-muted-foreground" />
            <p className="text-sm font-medium">
              {file ? file.name : 'Click to select CSV file'}
            </p>
            <p className="text-xs text-muted-foreground">
              CSV files only. Use the template format.
            </p>
          </div>
        </Label>
      </div>

      {uploading && (
        <div className="space-y-2">
          <Progress value={progress} />
          <p className="text-sm text-center text-muted-foreground">
            Uploading... {progress}%
          </p>
        </div>
      )}

      <Button
        onClick={handleUpload}
        disabled={!file || uploading}
        className="w-full"
      >
        {uploading ? 'Uploading...' : 'Upload CSV'}
      </Button>

      <div className="text-xs text-muted-foreground space-y-1">
        <p className="font-semibold">Required columns:</p>
        <p>{templateColumns.join(', ')}</p>
      </div>
    </div>
  );
}
