import { useState } from 'react';
import { ChevronRight, ChevronDown, Plus, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Category } from '@/types';

interface HierarchyTreeProps {
  categories: Category[];
  onAddChild?: (parentId: string | null) => void;
  onEdit?: (category: Category) => void;
  onDelete?: (categoryId: string) => void;
  onSelect?: (category: Category) => void;
  selectedId?: string;
  isAdmin?: boolean;
}

interface TreeNodeProps {
  category: Category;
  level: number;
  onAddChild?: (parentId: string) => void;
  onEdit?: (category: Category) => void;
  onDelete?: (categoryId: string) => void;
  onSelect?: (category: Category) => void;
  selectedId?: string;
  isAdmin?: boolean;
}

function TreeNode({
  category,
  level,
  onAddChild,
  onEdit,
  onDelete,
  onSelect,
  selectedId,
  isAdmin,
}: TreeNodeProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasChildren = category.children && category.children.length > 0;
  const isSelected = selectedId === category.id;

  return (
    <div>
      <div
        className={`flex items-center gap-2 py-2 px-3 rounded-lg transition-colors ${
          isSelected ? 'bg-primary text-primary-foreground' : 'hover:bg-accent'
        }`}
        style={{ paddingLeft: `${level * 1.5 + 0.75}rem` }}
      >
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="shrink-0"
        >
          {hasChildren ? (
            isExpanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )
          ) : (
            <div className="w-4 h-4" />
          )}
        </button>

        <button
          type="button"
          onClick={() => onSelect?.(category)}
          className="flex-1 text-left font-medium"
        >
          {category.name}
        </button>

        {isAdmin && (
          <div className="flex items-center gap-1 shrink-0">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={(e) => {
                e.stopPropagation();
                onAddChild?.(category.id);
              }}
            >
              <Plus className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={(e) => {
                e.stopPropagation();
                onEdit?.(category);
              }}
            >
              <Edit className="w-3 h-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={(e) => {
                e.stopPropagation();
                onDelete?.(category.id);
              }}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        )}
      </div>

      {isExpanded && hasChildren && (
        <div>
          {category.children?.map((child) => (
            <TreeNode
              key={child.id}
              category={child}
              level={level + 1}
              onAddChild={onAddChild}
              onEdit={onEdit}
              onDelete={onDelete}
              onSelect={onSelect}
              selectedId={selectedId}
              isAdmin={isAdmin}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function HierarchyTree({
  categories,
  onAddChild,
  onEdit,
  onDelete,
  onSelect,
  selectedId,
  isAdmin,
}: HierarchyTreeProps) {
  return (
    <div className="space-y-1">
      {isAdmin && (
        <Button
          variant="outline"
          size="sm"
          className="w-full mb-2"
          onClick={() => onAddChild?.(null)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Root Category
        </Button>
      )}

      {categories.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <p>No categories yet</p>
          {isAdmin && <p className="text-sm">Click above to add one</p>}
        </div>
      ) : (
        categories.map((category) => (
          <TreeNode
            key={category.id}
            category={category}
            level={0}
            onAddChild={onAddChild}
            onEdit={onEdit}
            onDelete={onDelete}
            onSelect={onSelect}
            selectedId={selectedId}
            isAdmin={isAdmin}
          />
        ))
      )}
    </div>
  );
}
