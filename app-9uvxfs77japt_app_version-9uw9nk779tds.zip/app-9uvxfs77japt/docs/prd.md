# BCS Preliminary Exam Preparation App Requirements Document

## 1. Application Overview

### 1.1 Application Name
BCS Preliminary Exam Preparation App

### 1.2 Application Description
A comprehensive, scalable BCS Preliminary Exam Preparation platform with unlimited hierarchical structure, powerful MCQ management system, interactive geographic quiz, exam engine, and administrative controls. The application supports both Android mobile app and web-based admin panel with centralized cloud database.

### 1.3 Target Platform
- Android Mobile Application
- Web Admin Panel (integrated within same application)

### 1.4 User Roles
- **Admin**: Full control over all modules, content management, user management, and analytics
- **Student**: Limited access for learning, practice, exams, and viewing notifications/routines

## 2. Core Functional Requirements

### 2.1 Home Page
- Clean dashboard UI with card-based layout
- Unlimited hierarchy add button for dynamic content structure
- Admin capabilities:
  - Add Category
  - Add Subcategory with unlimited nesting levels
  - Dynamically add module buttons:
    - Question Bank
    - Practice Question
    - Geographic Quiz
    - Exam
    - Notification
    - Routine

### 2.2 Question Bank Module

#### 2.2.1 Hierarchy System
- Unlimited nested structure: Subject → Topic → Subtopic → Chapter → (unlimited levels)
- Parent-child relationship support

#### 2.2.2 MCQ Management
- Manual MCQ addition with fields:
  - Question Text
  - Option A, B, C, D
  - Correct Answer Selection
  - Explanation
- Bulk CSV upload with standard format:
  - Columns: Question, OptionA, OptionB, OptionC, OptionD, CorrectAnswer, Explanation, QuestionImageURL, OptionAImageURL, OptionBImageURL, OptionCImageURL, OptionDImageURL, ExplanationImageURL
- Image support (JPG format) in:
  - Question
  - All Options
  - Explanation

#### 2.2.3 Student Features
- Favorite Button (Save Question)
- Mark for Review
- Category-wise filtering
- Search function

#### 2.2.4 Admin Control
- Edit / Delete / Hide / Publish questions
- Category management

### 2.3 Practice Question Module

#### 2.3.1 Practice Modes
- **Practice Mode**: Instant answer display with explanation
- **Exam Mode**: Answers shown at end

#### 2.3.2 Features
- Same unlimited hierarchy system as Question Bank
- Manual MCQ addition
- Bulk CSV upload with standard format
- Image support (JPG) in question, options, and explanation
- Favorite Button
- Score Tracking
- Performance Analytics

### 2.4 Geographic Quiz Module

#### 2.4.1 Interactive Map Coverage
- **Bangladesh**: Divisions, Districts, Specific Important Places
- **World Map**: Countries and regions
- **Geographic Features**: Rivers, Straits, Mountains

#### 2.4.2 Quiz Modes
- Click on Map → Answer Question
- Division/District Identification
- Country Identification
- Flag Identification
- Capital Quiz

#### 2.4.3 Features
- Same unlimited hierarchy system
- Manual MCQ addition
- Bulk CSV upload with standard format
- Image support (JPG)
- Explanation section
- Leaderboard system

### 2.5 Exam Module

#### 2.5.1 Exam Modes
- **Full Exam Mode**: Complete exam simulation
- **Custom Exam Mode**: User-defined parameters

#### 2.5.2 Custom Exam Configuration
- Positive Marking (customizable points)
- Negative Marking (customizable deduction)
- Time Limit (customizable duration)
- Question Limit (customizable count)
- Random Question Generator
- Subject-wise Selection

#### 2.5.3 Features
- Same unlimited hierarchy system
- Manual MCQ addition
- Bulk CSV upload with standard format
- Image support (JPG)
- Auto Result Generation
- Rank System
- Review Wrong Answers
- Detailed Performance Analysis

### 2.6 Notification System

#### 2.6.1 Admin Capabilities
- Publish Notice
- Push Notification to Users
- Schedule Notification

#### 2.6.2 Student Features
- View Notification Feed
- Mark as Read

### 2.7 Routine Module

#### 2.7.1 Admin Capabilities
- Publish Routine Manually
- Upload Routine PDF
- Update Routine
- Delete Routine

#### 2.7.2 Student Features
- View Routine
- Download PDF

## 3. Admin Panel (Full Control)

### 3.1 Content Management
- Control all modules
- Add / Edit / Delete any content
- Manage unlimited hierarchy structure

### 3.2 User Management
- Manage user accounts
- Block / Unblock users
- View user activity

### 3.3 Analytics Dashboard
- Most Attempted Questions
- Most Wrong Questions
- User performance statistics
- Module usage analytics

### 3.4 System Management
- Backup & Restore Database
- System configuration

## 4. Authentication & User Management

### 4.1 User Registration & Login
- Email and Password authentication
- Role-based access control (Admin / Student)

### 4.2 User Roles
- Admin: Full system access
- Student: Limited access to learning modules

## 5. Database Structure Requirements

### 5.1 Core Tables
- Unlimited Nested Categories (Parent-Child relationship)
- Image Storage System
- CSV Bulk Import Engine
- User Favorite Table
- Exam Result Table
- Analytics Tracking Table
- Notification Table
- Routine Table

### 5.2 Data Management
- Cloud-based centralized database
- Fast query optimization
- Scalable architecture

## 6. UI/UX Requirements

### 6.1 Design Principles
- Mobile-first design
- Clean & Minimal UI
- Dark/Light Mode support
- Fast loading performance
- Smooth animations

### 6.2 Navigation & Search
- Search function in every module
- Filter by Subject / Topic
- Category-wise filtering

## 7. Technical Requirements

### 7.1 Architecture
- Cloud-based centralized database
- Role-based authentication system
- Scalable architecture
- Fast query optimization

### 7.2 Optional Features
- Offline practice cache
- Daily MCQ Feature
- Streak System
- Leaderboard
- Bookmark Sync across devices
- Export Result as PDF

## 8. CSV Upload Standard Format

### 8.1 CSV Template Structure
Columns:
- Question
- OptionA
- OptionB
- OptionC
- OptionD
- CorrectAnswer
- Explanation
- QuestionImageURL
- OptionAImageURL
- OptionBImageURL
- OptionCImageURL
- OptionDImageURL
- ExplanationImageURL

### 8.2 Image Handling
- Support JPG format
- Image URLs stored in database
- Images displayed in questions, options, and explanations